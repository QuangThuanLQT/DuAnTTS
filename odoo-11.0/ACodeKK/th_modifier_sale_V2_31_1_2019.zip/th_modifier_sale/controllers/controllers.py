# -*- coding: utf-8 -*-
from odoo import http

# class ThSale(http.Controller):
#     @http.route('/th_sale/th_sale/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/th_sale/th_sale/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('th_sale.listing', {
#             'root': '/th_sale/th_sale',
#             'objects': http.request.env['th_sale.th_sale'].search([]),
#         })

#     @http.route('/th_sale/th_sale/objects/<model("th_sale.th_sale"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('th_sale.object', {
#             'object': obj
#         })